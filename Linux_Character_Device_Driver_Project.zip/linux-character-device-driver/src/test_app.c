/**
 * Userspace Test Application for Character Device Driver
 * 
 * This program tests the character device driver by:
 * - Opening the device file
 * - Writing data to the device
 * - Reading data from the device
 * - Closing the device
 * 
 * Author: Tushar Kumar
 * Compile: gcc -o test_app test_app.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

#define DEVICE_PATH "/dev/char_device"
#define BUFFER_SIZE 1024

int main() {
    int fd;
    char write_buffer[] = "Hello from userspace! Testing character device driver.";
    char read_buffer[BUFFER_SIZE];
    ssize_t bytes_written, bytes_read;
    
    printf("=== Character Device Driver Test Application ===\n\n");
    
    // Open the device file
    printf("[1] Opening device file: %s\n", DEVICE_PATH);
    fd = open(DEVICE_PATH, O_RDWR);
    if (fd < 0) {
        perror("Error: Failed to open device file");
        printf("Make sure the kernel module is loaded and device file exists.\n");
        printf("Run: sudo insmod char_device_driver.ko\n");
        return EXIT_FAILURE;
    }
    printf("    Device opened successfully (fd = %d)\n\n", fd);
    
    // Write data to the device
    printf("[2] Writing data to device...\n");
    printf("    Data: \"%s\"\n", write_buffer);
    bytes_written = write(fd, write_buffer, strlen(write_buffer));
    if (bytes_written < 0) {
        perror("Error: Failed to write to device");
        close(fd);
        return EXIT_FAILURE;
    }
    printf("    Successfully wrote %zd bytes to device\n\n", bytes_written);
    
    // Reset file offset to beginning
    printf("[3] Resetting file offset to beginning...\n");
    if (lseek(fd, 0, SEEK_SET) < 0) {
        perror("Error: Failed to reset file offset");
        close(fd);
        return EXIT_FAILURE;
    }
    printf("    File offset reset successfully\n\n");
    
    // Read data from the device
    printf("[4] Reading data from device...\n");
    memset(read_buffer, 0, BUFFER_SIZE);
    bytes_read = read(fd, read_buffer, BUFFER_SIZE);
    if (bytes_read < 0) {
        perror("Error: Failed to read from device");
        close(fd);
        return EXIT_FAILURE;
    }
    printf("    Read %zd bytes from device\n", bytes_read);
    printf("    Data: \"%s\"\n\n", read_buffer);
    
    // Verify data integrity
    printf("[5] Verifying data integrity...\n");
    if (strcmp(write_buffer, read_buffer) == 0) {
        printf("    ✓ SUCCESS: Data matches!\n");
        printf("    Write buffer and read buffer contain identical data.\n\n");
    } else {
        printf("    ✗ FAILURE: Data mismatch!\n");
        printf("    Write buffer: \"%s\"\n", write_buffer);
        printf("    Read buffer:  \"%s\"\n\n", read_buffer);
    }
    
    // Close the device
    printf("[6] Closing device file...\n");
    if (close(fd) < 0) {
        perror("Error: Failed to close device file");
        return EXIT_FAILURE;
    }
    printf("    Device closed successfully\n\n");
    
    printf("=== Test completed successfully! ===\n");
    printf("\nTo view kernel messages, run: dmesg | tail -20\n");
    
    return EXIT_SUCCESS;
}
