/**
 * Linux Character Device Driver - Loadable Kernel Module (LKM)
 * 
 * This module implements a basic character device driver with:
 * - Module initialization and cleanup
 * - file_operations structure (open, read, write, release)
 * - Major/minor number allocation
 * - Kernel-space memory management (kmalloc/kfree)
 * - User-kernel data transfer
 * - Kernel logging (printk)
 * 
 * Author: Tushar Kumar
 * Description: Learning project for Linux kernel driver development
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/uaccess.h>
#include <linux/slab.h>

#define DEVICE_NAME "char_device"
#define CLASS_NAME "char_class"
#define BUFFER_SIZE 1024

// Module information
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Tushar Kumar");
MODULE_DESCRIPTION("A simple Linux character device driver");
MODULE_VERSION("1.0");

// Device variables
static int major_number;
static struct class *char_class = NULL;
static struct device *char_device = NULL;
static struct cdev char_cdev;
static char *device_buffer;
static size_t buffer_size = 0;

// Function prototypes
static int char_device_open(struct inode *inodep, struct file *filep);
static int char_device_release(struct inode *inodep, struct file *filep);
static ssize_t char_device_read(struct file *filep, char __user *buffer, 
                                 size_t len, loff_t *offset);
static ssize_t char_device_write(struct file *filep, const char __user *buffer,
                                  size_t len, loff_t *offset);

// File operations structure
static struct file_operations fops = {
    .owner = THIS_MODULE,
    .open = char_device_open,
    .read = char_device_read,
    .write = char_device_write,
    .release = char_device_release,
};

/**
 * Module initialization function
 * Called when the module is loaded using insmod
 */
static int __init char_device_init(void) {
    dev_t dev_num;
    int result;
    
    printk(KERN_INFO "char_device: Initializing character device driver\n");
    
    // Allocate device number dynamically
    result = alloc_chrdev_region(&dev_num, 0, 1, DEVICE_NAME);
    if (result < 0) {
        printk(KERN_ERR "char_device: Failed to allocate device number\n");
        return result;
    }
    major_number = MAJOR(dev_num);
    printk(KERN_INFO "char_device: Registered with major number %d\n", major_number);
    
    // Create device class
    char_class = class_create(CLASS_NAME);
    if (IS_ERR(char_class)) {
        unregister_chrdev_region(dev_num, 1);
        printk(KERN_ERR "char_device: Failed to create device class\n");
        return PTR_ERR(char_class);
    }
    printk(KERN_INFO "char_device: Device class created successfully\n");
    
    // Initialize cdev structure
    cdev_init(&char_cdev, &fops);
    char_cdev.owner = THIS_MODULE;
    
    // Add cdev to the system
    result = cdev_add(&char_cdev, dev_num, 1);
    if (result < 0) {
        class_destroy(char_class);
        unregister_chrdev_region(dev_num, 1);
        printk(KERN_ERR "char_device: Failed to add cdev\n");
        return result;
    }
    
    // Create device
    char_device = device_create(char_class, NULL, dev_num, NULL, DEVICE_NAME);
    if (IS_ERR(char_device)) {
        cdev_del(&char_cdev);
        class_destroy(char_class);
        unregister_chrdev_region(dev_num, 1);
        printk(KERN_ERR "char_device: Failed to create device\n");
        return PTR_ERR(char_device);
    }
    
    // Allocate kernel buffer using kmalloc
    device_buffer = kmalloc(BUFFER_SIZE, GFP_KERNEL);
    if (!device_buffer) {
        device_destroy(char_class, dev_num);
        cdev_del(&char_cdev);
        class_destroy(char_class);
        unregister_chrdev_region(dev_num, 1);
        printk(KERN_ERR "char_device: Failed to allocate memory with kmalloc\n");
        return -ENOMEM;
    }
    
    printk(KERN_INFO "char_device: Character device driver loaded successfully\n");
    printk(KERN_INFO "char_device: Device created at /dev/%s\n", DEVICE_NAME);
    return 0;
}

/**
 * Module cleanup function
 * Called when the module is unloaded using rmmod
 */
static void __exit char_device_exit(void) {
    dev_t dev_num = MKDEV(major_number, 0);
    
    // Free kernel buffer using kfree
    kfree(device_buffer);
    
    // Destroy device and class
    device_destroy(char_class, dev_num);
    cdev_del(&char_cdev);
    class_destroy(char_class);
    unregister_chrdev_region(dev_num, 1);
    
    printk(KERN_INFO "char_device: Character device driver unloaded successfully\n");
}

/**
 * Open function - called when device file is opened
 */
static int char_device_open(struct inode *inodep, struct file *filep) {
    printk(KERN_INFO "char_device: Device opened\n");
    return 0;
}

/**
 * Release function - called when device file is closed
 */
static int char_device_release(struct inode *inodep, struct file *filep) {
    printk(KERN_INFO "char_device: Device closed\n");
    return 0;
}

/**
 * Read function - called when userspace reads from device
 */
static ssize_t char_device_read(struct file *filep, char __user *buffer,
                                 size_t len, loff_t *offset) {
    size_t bytes_to_read;
    
    // Check if we have data to read
    if (*offset >= buffer_size) {
        printk(KERN_INFO "char_device: Read - no more data available\n");
        return 0;
    }
    
    // Calculate bytes to read
    bytes_to_read = min(len, buffer_size - (size_t)*offset);
    
    // Copy data from kernel space to user space
    if (copy_to_user(buffer, device_buffer + *offset, bytes_to_read)) {
        printk(KERN_ERR "char_device: Failed to copy data to user space\n");
        return -EFAULT;
    }
    
    *offset += bytes_to_read;
    printk(KERN_INFO "char_device: Read %zu bytes from device\n", bytes_to_read);
    
    return bytes_to_read;
}

/**
 * Write function - called when userspace writes to device
 */
static ssize_t char_device_write(struct file *filep, const char __user *buffer,
                                  size_t len, loff_t *offset) {
    size_t bytes_to_write;
    
    // Calculate bytes to write (don't exceed buffer size)
    bytes_to_write = min(len, (size_t)(BUFFER_SIZE - 1));
    
    // Copy data from user space to kernel space
    if (copy_from_user(device_buffer, buffer, bytes_to_write)) {
        printk(KERN_ERR "char_device: Failed to copy data from user space\n");
        return -EFAULT;
    }
    
    // Null terminate the string
    device_buffer[bytes_to_write] = '\0';
    buffer_size = bytes_to_write;
    
    printk(KERN_INFO "char_device: Wrote %zu bytes to device\n", bytes_to_write);
    
    return bytes_to_write;
}

// Register module init and exit functions
module_init(char_device_init);
module_exit(char_device_exit);
